OBSERVAÇÃO: O arquivo principal do projeto foi subido como zip, pois a pasta principal estava dando erro 
ao tentar enviar para o git, e faltam apenas 20 minutos para o prazo de entrega.

Informações de acesso ao banco:

ORACLE_DB_USER = ADMIN
ORACLE_DB_PASSWORD = 'RJf&]E^7s76.'
ORACLE_CONN_STR = (description= (retry_count=20)(retry_delay=3)(address=(protocol=tcps)(port=1521)(host=adb.sa-saopaulo-1.oraclecloud.com))(connect_data=(service_name=g9ff0ba4ed8781e_database2023_high.adb.oraclecloud.com))(security=(ssl_server_dn_match=yes)))